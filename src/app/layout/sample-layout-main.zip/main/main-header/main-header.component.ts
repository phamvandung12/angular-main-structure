import { GoogleLoginProvider, SocialAuthService } from '@abacritt/angularx-social-login';
import { ApplicationRef, ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { SystemConstant } from '@constants/system.constant';
import { UrlConstant } from '@constants/url.constant';
import langDataEn from '@languages/en.json';
import langDataVi from '@languages/vi.json';
import { AuthService } from '@services/auth/auth.service';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { concat, first, of, switchMap, takeWhile, timer } from 'rxjs';

@Component({
  selector: 'app-main-header',
  templateUrl: './main-header.component.html',
  styleUrl: './main-header.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    NzGridModule,
    NzDropDownModule,
    NzButtonModule,
  ]
})
export class MainHeaderComponent implements OnInit {

  private authSvc = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);
  private appRef = inject(ApplicationRef);
  private alert = inject(ToastrService);
  private socialLoginSvc = inject(SocialAuthService);
  private spinner = inject(NgxSpinnerService);
  private router = inject(Router);

  urlConst = UrlConstant;

  isLogin = false;
  isAdmin = false;
  isGiangVien = false;

  userName = 'Menu';
  userAvatarLink = '';

  // Language ///////////////////
  langCode: 'en' | 'vi' = localStorage.getItem('language') as 'en' | 'vi' ?? 'vi';
  langData: Record<string, string> = (localStorage.getItem('language') === 'en' ? langDataEn : langDataVi).LAYOUT.MAIN.HEADER;

  ngOnInit(): void {
    localStorage.setItem('language', this.langCode);
    this.checkLogin();
    concat(this.appRef.isStable.pipe(first(isStable => isStable)), timer(0, 1000))
      .pipe(takeWhile(() => !this.isLogin))
      .subscribe(() => {
        this.checkLogin();
      });
  }

  checkLogin(): void {
    if (this.authSvc.getAuthData() && this.authSvc.getToken()) {
      this.isLogin = true;
      this.isAdmin = Object.values(SystemConstant.MNG_ROLE).some(role => this.authSvc.checkRole(role));
      // queuedCheckRole
      if (this.isAdmin) {
        this.authSvc.checkRoleObs(SystemConstant.MNG_ROLE.ADMIN)
          .subscribe(correct => {
            if (!correct) {
              this.authSvc.doLogout(UrlConstant.ROUTE.MAIN.HOMEPAGE);
              this.isLogin = false;
              this.alert.error(this.langData.QUYEN_HAN_CAP_NHAT);
            }
          });
      }
      this.isGiangVien = this.authSvc.checkRole(SystemConstant.ROLE.GIANG_VIEN);
      // queuedCheckRole
      if (this.isGiangVien) {
        this.authSvc.checkRoleObs(SystemConstant.ROLE.GIANG_VIEN)
          .subscribe(correct => {
            if (!correct) {
              this.authSvc.doLogout(UrlConstant.ROUTE.MAIN.HOMEPAGE);
              this.isLogin = false;
              this.alert.error(this.langData.QUYEN_HAN_CAP_NHAT);
            }
          });
      }

      this.userAvatarLink = this.authSvc.getAvatarOfLogin() ?? '';
      this.userName = this.authSvc.getNameOfLogin();
      this.cdr.detectChanges();
    }
  }

  onLogOut(): void {
    this.authSvc.doLogout(UrlConstant.ROUTE.MAIN.HOMEPAGE);
    this.isLogin = false;
  }

  onLoginWithGoogle(): void {
    this.socialLoginSvc.getAccessToken(GoogleLoginProvider.PROVIDER_ID).then(accessToken => {
      if (accessToken) {
        this.spinner.show();
        this.authSvc.getGoogleUserData(accessToken)
          .subscribe(user => {
            this.authSvc.doLoginGoogle(accessToken)
              .pipe(
                switchMap(res => {
                  if (res?.access_token) {
                    this.authSvc.setToken(res.access_token ?? '');
                    delete res.access_token;
                    this.authSvc.setAuthData((Object.assign(res, {
                      avatar: user.photos.length ? user.photos.find(x => x.metadata?.primary)?.url : '',
                      fullName: user.names.length ? user.names.find(x => x.metadata?.primary)?.displayName : 'User'
                    })));
                    return this.authSvc.getUaaRoleData();
                  } else {
                    return of(null);
                  }
                })
              )
              .subscribe({
                next: res => {
                  if (res?.authenticated) {
                    this.authSvc.setRoles(res.authorities);
                  }
                  this.redirectUser();
                }
              });
          });
      }
    });
  }

  redirectUser() {
    if (this.authSvc.checkRole(SystemConstant.MNG_ROLE.ADMIN)) {
      this.router.navigateByUrl(UrlConstant.ROUTE.MANAGEMENT.DASHBOARD);
    } else {
      this.router.navigateByUrl(UrlConstant.ROUTE.MAIN.HOMEPAGE);
    }
  }

  switchLang(lang: string): void {
    localStorage.setItem('language', lang);
    // TODO: Set Nz locale
    window.location.reload();
  }

}
