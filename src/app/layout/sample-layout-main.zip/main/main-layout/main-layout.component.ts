import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, HostListener, inject, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { UrlConstant } from '@constants/url.constant';
import { NzDrawerModule } from 'ng-zorro-antd/drawer';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { take, timer } from 'rxjs';
import { MainFooterComponent } from '../main-footer/main-footer.component';
import { MainHeaderComponent } from '../main-header/main-header.component';
import { MainSidebarComponent } from '../main-sidebar/main-sidebar.component';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrl: './main-layout.component.css',
  imports: [
    RouterOutlet,
    NgClass,
    NzGridModule,
    NzLayoutModule,
    NzDrawerModule,
    MainHeaderComponent,
    MainFooterComponent,
    MainSidebarComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MainLayoutComponent implements OnInit {

  private router = inject(Router);

  sliderWidth = 270;
  isShowSider = true;
  isShowDrawer = false;
  isPubPage = this.checkIsPublicPage(this.router.url);

  constructor() {
    this.router.events.subscribe({
      next: res => {
        if (res instanceof NavigationEnd) {
          this.isPubPage = this.checkIsPublicPage(res.urlAfterRedirects);
          this.isShowSider = !this.isPubPage;
          this.ngOnInit();
        }
      }
    });
  }

  @HostListener('window:resize', ['$event'])
  onResize(): void {
    const scWidth = window.innerWidth;

    if (scWidth >= 992) {
      this.isShowSider = !this.isPubPage;
      this.isShowDrawer = false;
    } else {
      this.isShowSider = false;
    }

    if (scWidth >= 1500) {
      this.sliderWidth = 285;
    } else if (scWidth >= 1300) {
      this.sliderWidth = 280;
    } else if (scWidth >= 1200) {
      this.sliderWidth = 275;
    } else {
      this.sliderWidth = 270;
    }
  }

  ngOnInit(): void {
    this.isShowSider = !this.isPubPage;
    // Call firstime
    window.dispatchEvent(new Event('resize'));
    // Then do check
    timer(0, 1000).pipe(take(10)).subscribe(() => window.dispatchEvent(new Event('resize')));
  }

  checkIsPublicPage(url: string): boolean {
    return url.includes('/#/') ||
      url.includes(UrlConstant.ROUTE.AUTH.LOGIN) ||
      url === UrlConstant.ROUTE.MAIN.HOMEPAGE;
  }
}
