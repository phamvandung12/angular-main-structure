import { NgClass } from '@angular/common';
import { ChangeDetectionStrategy, Component, inject, OnInit, viewChildren } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ISiderMenu } from '@models/common/sider-menu.model';
import { AuthService } from '@services/auth/auth.service';
import { NzMenuModule, NzSubMenuComponent } from 'ng-zorro-antd/menu';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';

@Component({
  selector: 'app-main-sidebar',
  imports: [
    RouterLink,
    NgClass,
    NzMenuModule,
    NzToolTipModule,
  ],
  templateUrl: './main-sidebar.component.html',
  styleUrl: './main-sidebar.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MainSidebarComponent implements OnInit {

  private authSvc = inject(AuthService);

  readonly subMenuItem = viewChildren<NzSubMenuComponent>('subMenuItem');

  // Language ///////////////////
  // langCode: 'en' | 'vi' = localStorage.getItem('language') as 'en' | 'vi' ?? 'vi';
  // langData: Record<string, string> = (localStorage.getItem('language') === 'en' ? langDataEn : langDataVi).LAYOUT.MAIN.SIDEBAR;
  ///////////////////////////////

  nameOfUser = '';
  avatarOfUser = '';

  listMenu: ISiderMenu[] = [
    // ...keKhaiUserMenu,
    // ...traCuuUserMenu,
  ];

  listRoleUser: string[] = [];

  ngOnInit(): void {
    this.listRoleUser = this.authSvc.getRoles();

    this.nameOfUser = this.authSvc.getNameOfLogin();
    this.avatarOfUser = this.authSvc.getAvatarOfLogin();
  }

  checkRole(roles: string[]): boolean {
    return this.authSvc.checkListRole(roles);
  }

  // autoHideMenu() {
  //   this.subMenuItem.forEach(e => {
  //     if (!e.isSelected && !e.isActive && e.nzOpen) {
  //       e.toggleSubMenu();
  //     }
  //   });
  // }

}
